Malware name: Yellow Skull
Type: Ransomware
Version: 2.0 (Scorpion 1.0 style but also overwrite mbr and can't be unlocked)
Damage rate: Destructive
made in: Visual Basic, C++
Inspired by: Scorpion Virus, Death Virus.exe, blue_skull.exe
made by: pankoza
Warning: This Malware is destructive and overwrite MBR run it only on vm and don't use the code for cybercrime or cyberweapon purposes